<?php

namespace App\mobile_v1\app\family;

class FamilyGodfather
{
  /**
   * Create a new class instance.
   */
  public function __construct(private string $userId)
  {
    //
  }

  # GOD FATHER ----------------------------------------------------------------- :
  /** Get child godfather */
  function getGodParent()
  {
    //
  }

  /** Get all children of a godfather. */
  function getGodParentChildren()
  {
    //
  }

  /** Send a Validable invitation to a partner of a couple. */
  function sendInvitationToGodParent()
  {
    //
  }

  /** Cancel or revoque an invitation to Godfather. */
  function revoqueInvitationToGodParent()
  {
    //
  }

  /** Revoque a child in Godfathering. */
  function revoqueChildInGodfathering()
  {
    //
  }
}
