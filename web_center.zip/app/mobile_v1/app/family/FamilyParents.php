<?php

namespace App\mobile_v1\app\family;

class FamilyParents
{
  /**
   * Create a new class instance.
   */
  public function __construct(private string $userId)
  {
    //
  }

  # PARENT --------------------------------------------------------------------- :
  /** Get a user parents list (of all both partners) */
  function getParents()
  {
    //
  }
}
