<?php

namespace App\mobile_v1\app\home;

class PartialHomeDatas
{
  /**
   * Create a new class instance.
   */
  public function __construct()
  {
    //
  }

  /** Get home slidershow pictures. */
  public function homeSlideshowPictures()
  {
    //
  }
}
