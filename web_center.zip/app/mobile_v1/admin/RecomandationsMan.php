<?php

namespace App\mobile_v1\admin;

class RecomandationsMan
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
