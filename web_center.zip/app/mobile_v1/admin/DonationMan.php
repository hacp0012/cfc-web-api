<?php

namespace App\mobile_v1\admin;

class DonationMan
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
