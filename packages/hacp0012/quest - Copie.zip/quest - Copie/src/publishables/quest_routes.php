<?php

/**
 * This contain a list of all spawed quest classes.
 */

return [
  # Spawed classes names here ...

  /* It is now possible to specifie a path to a directory.
  |
  | Exemple : 'app/demo',
  | - This must be a valide path started at the Laravel base path.
  | - The Laravel base path start at 'base_path()'.
  |
  | All namespace containing in this folder or subfolder will be registred.
  */

  // 'app',
];
