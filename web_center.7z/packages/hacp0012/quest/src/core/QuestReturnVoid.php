<?php

namespace Hacp0012\Quest\core;

/** Void state value. */
class QuestReturnVoid
{
  /**
   * Create a new class instance.
   */
  public function __construct() {}
}
