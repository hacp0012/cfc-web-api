<?php

namespace App\mobile_v1\admin;

class ContactsMan
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
