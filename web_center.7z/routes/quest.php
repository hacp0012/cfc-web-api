<?php

use App\Quest\demo\QuestTest;

return [
  QuestTest::class,
];
