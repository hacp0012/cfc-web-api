<?php

use App\mobile_v1\app\FindCFCBehind;
use Hacp0012\Quest\Quest;

Quest::spawn('find_around', FindCFCBehind::class);
